@echo off
setlocal
cd /d "%~dp0"
title Defect Recount V10 Build

echo ================================================
echo Defect Recount V10 Build
echo Python 3.12 and PyInstaller
echo ================================================
echo.

py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PY

python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON

echo ERROR: Python 3.12 was not found.
echo Install Python 3.12 and enable Add Python to PATH.
pause
exit /b 1

:USE_PY
echo Using: py -3.12
py -3.12 --version
py -3.12 -m ensurepip --upgrade > build_pip.log 2>&1
if errorlevel 1 goto PIP_ERROR
py -3.12 -m pip install --upgrade pip >> build_pip.log 2>&1
if errorlevel 1 goto PIP_ERROR
py -3.12 -m pip install --upgrade pyinstaller >> build_pip.log 2>&1
if errorlevel 1 goto PIP_ERROR
py -3.12 -m PyInstaller --version
if errorlevel 1 goto BUILD_ERROR
goto BUILD_PY

:USE_PYTHON
echo Using: python
python --version
python -m ensurepip --upgrade > build_pip.log 2>&1
if errorlevel 1 goto PIP_ERROR
python -m pip install --upgrade pip >> build_pip.log 2>&1
if errorlevel 1 goto PIP_ERROR
python -m pip install --upgrade pyinstaller >> build_pip.log 2>&1
if errorlevel 1 goto PIP_ERROR
python -m PyInstaller --version
if errorlevel 1 goto BUILD_ERROR
goto BUILD_PYTHON

:BUILD_PY
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist defect_recount_V10.spec del /q defect_recount_V10.spec
if not exist defect_recount_V10.py goto FILE_ERROR
if not exist converter_logo.ico goto FILE_ERROR
echo Building EXE...
py -3.12 -m PyInstaller --noconfirm --clean --onefile --windowed --name defect_recount_V10 --icon=converter_logo.ico defect_recount_V10.py > build_pyinstaller.log 2>&1
if errorlevel 1 goto BUILD_ERROR
goto VERIFY

:BUILD_PYTHON
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist defect_recount_V10.spec del /q defect_recount_V10.spec
if not exist defect_recount_V10.py goto FILE_ERROR
if not exist converter_logo.ico goto FILE_ERROR
echo Building EXE...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name defect_recount_V10 --icon=converter_logo.ico defect_recount_V10.py > build_pyinstaller.log 2>&1
if errorlevel 1 goto BUILD_ERROR
goto VERIFY

:VERIFY
if not exist dist\defect_recount_V10.exe goto BUILD_ERROR
echo.
echo BUILD SUCCESS
echo Output: dist\defect_recount_V10.exe
echo Log: build_pyinstaller.log
pause
exit /b 0

:PIP_ERROR
echo ERROR: pip or PyInstaller installation failed.
echo Check build_pip.log
pause
exit /b 1

:FILE_ERROR
echo ERROR: defect_recount_V10.py or converter_logo.ico is missing.
echo Put this BAT in the same folder as the files.
pause
exit /b 1

:BUILD_ERROR
echo ERROR: PyInstaller build failed.
echo Check build_pyinstaller.log
pause
exit /b 1

# -*- mode: python ; coding: utf-8 -*-
# Windows / Python 3.12
from PyInstaller.building.build_main import Analysis, PYZ, EXE

a = Analysis(['defect_recount_V10.py'], pathex=[], binaries=[], datas=[],
             hiddenimports=[], hookspath=[], hooksconfig={}, runtime_hooks=[],
             excludes=[], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, a.binaries, a.datas, [],
          name='defect_recount_V10', debug=False, bootloader_ignore_signals=False,
          strip=False, upx=True, console=False, icon='converter_logo.ico')

# Defect Recount V10 科技風部署包

## 已加入功能

- 批次匯入 GTS / DM 時顯示即時進度條與目前檔名。
- 批次轉檔／輸出時顯示進度與檔案計數。
- 進度視窗可要求停止後續檔案處理。
- DM 對 GTS 的檔名、Strip_2D 比對改用索引查找，從逐筆掃描改善為接近 O(1) 查找。
- 保留原有 XML 更新、瑕疵座標、Strip scrapped、ZIP 輸出邏輯。

## Windows Python 3.12 打包

請在 Windows 安裝 64-bit Python 3.12，將本資料夾解壓縮後雙擊：

```text
build_windows_py312.bat
```

或在命令列執行：

```bat
py -3.12 -m pip install --upgrade pyinstaller
py -3.12 -m PyInstaller --noconfirm --clean --onefile --windowed --name defect_recount_V10 --icon=converter_logo.ico defect_recount_V10.py
```

完成後執行檔會位於 `dist\\defect_recount_V10.exe`。

## 重要說明

本 Linux 沙盒無法直接產生可在 Windows 執行的 `.exe`；部署包已包含原始程式、ICO/PNG/SVG 圖示與 Windows Python 3.12 打包批次檔。請在 Windows 執行 `build_windows_py312.bat` 產生真正的 `.exe`。

程式仍要求 Python 3.12，因為檔案內嵌了 Python 3.12 編譯的 V9 核心。

## Logo

新版 Logo 為雙向轉換環，使用石墨藍、薄荷青與薰衣草紫配色。程式會將 64px PNG 內嵌到 Tkinter 主視窗，因此打包後不依賴外部 PNG；`converter_logo.ico` 則供 PyInstaller 設定 EXE 圖示使用。

# 舊電腦使用建議

## 進度條

程式目前會在 GTS 匯入、DM 匯入、XML 批次轉檔／輸出時顯示目前檔名與處理數量。進度條改為約每 0.12 秒刷新一次，避免大量檔案時 UI 重繪拖慢核心處理。

## 建議打包方式

一般電腦使用 `build_windows_py312.bat`，產生單一 EXE。

較舊或較慢的電腦建議使用 `build_windows_py312_onedir.bat`，產生：

```text
dist\\defect_recount_V10\\defect_recount_V10.exe
```

`onedir` 首次啟動通常較快，也不需要每次啟動都將整個程式解壓到暫存資料夾；但部署時必須保留整個 `dist\\defect_recount_V10` 資料夾，不能只複製其中的 exe。

## 注意事項

Python 3.12 的 PyInstaller 執行檔建議使用 Windows 10/11 64-bit。若舊電腦是非常早期的 Windows 版本，可能不支援 Python 3.12，需要另行使用相容的 Python 版本重新打包。

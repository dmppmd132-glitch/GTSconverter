@echo off
setlocal
cd /d "%~dp0"
title Defect Recount V10 Onedir Build

echo Defect Recount V10 - Python 3.12 - Onedir
py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PY
python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON
echo ERROR: Python 3.12 was not found.
pause
exit /b 1

:USE_PY
py -3.12 -m pip install --upgrade pyinstaller > build_pip.log 2>&1
if errorlevel 1 goto ERROR
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist defect_recount_V10.spec del /q defect_recount_V10.spec
py -3.12 -m PyInstaller --noconfirm --clean --onedir --windowed --name defect_recount_V10 --icon=converter_logo.ico defect_recount_V10.py > build_pyinstaller.log 2>&1
if errorlevel 1 goto ERROR
goto DONE

:USE_PYTHON
python -m pip install --upgrade pyinstaller > build_pip.log 2>&1
if errorlevel 1 goto ERROR
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist defect_recount_V10.spec del /q defect_recount_V10.spec
python -m PyInstaller --noconfirm --clean --onedir --windowed --name defect_recount_V10 --icon=converter_logo.ico defect_recount_V10.py > build_pyinstaller.log 2>&1
if errorlevel 1 goto ERROR

goto DONE

:DONE
echo BUILD SUCCESS
echo Output: dist\defect_recount_V10\defect_recount_V10.exe
pause
exit /b 0

:ERROR
echo BUILD FAILED - check build_pip.log or build_pyinstaller.log
pause
exit /b 1
